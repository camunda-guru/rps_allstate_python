from flask import Blueprint, request, render_template

module_one = Blueprint("auth", __name__, url_prefix="/auth")

@module_one.route("/home")
def home():
    return render_template("insurancemodule/welcome.html")