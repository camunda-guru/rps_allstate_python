from flask import Flask, render_template

app = Flask(__name__)
app.config.from_object("config")

from app.insurancemodule.controllers import insurancemodule

app.register_blueprint(insurancemodule)